package education;

public class SubjectTaken 
{
	private String subjectName;
	private int mark;
	SubjectTaken(String subjectName,int mark)
	{
		this.subjectName = subjectName;
		this.mark = mark;
	}
	
	public int getMark()
	{
		return mark;
	}
	
	public String toString()
	{
		String msg=null;
		
		  return msg;
	}
}